void main(){
  Map<String, dynamic> user = {
  'name': 'Tung',
  'age': 20,
  'isStudent': true,
};

}